// SPDX-License-Identifier: GPL-3.0-only
// Pager transition logic adapted from AsteriskNG 1.4.2.
// Copyright 2026, AsteriskNG contributors

package com.openrecorder.app

import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.MutatePriority
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import top.yukonga.miuix.kmp.basic.Scaffold
import top.yukonga.miuix.kmp.theme.MiuixTheme
import kotlin.math.abs

private const val RECORD_PAGE = 0
private const val RECORDINGS_PAGE = 1
private const val SETTINGS_PAGE = 2
private const val PAGE_COUNT = 3

@Composable
internal fun RecorderApp(
    onRecordingsVisible: () -> Unit,
    recordContent: @Composable () -> Unit,
    settingsContent: @Composable () -> Unit,
    recordingsContent: @Composable () -> Unit,
) {
    val pagerState = rememberPagerState(
        initialPage = RECORD_PAGE,
        pageCount = { PAGE_COUNT },
    )
    val recorderPagerState = rememberRecorderPagerState(pagerState)
    val recordLabel = stringResource(R.string.nav_record)
    val settingsLabel = stringResource(R.string.nav_settings)
    val recordingsLabel = stringResource(R.string.nav_recordings)
    val navigationItems = remember(recordLabel, settingsLabel, recordingsLabel) {
        listOf(
            Triple(recordLabel, "⦿", RECORD_PAGE),
            Triple(recordingsLabel, "▣", RECORDINGS_PAGE),
            Triple(settingsLabel, "☷", SETTINGS_PAGE),
        )
    }

    LaunchedEffect(recorderPagerState.pagerState.currentPage) {
        recorderPagerState.syncPage()
    }

    LaunchedEffect(recorderPagerState.selectedPage) {
        if (recorderPagerState.selectedPage == RECORDINGS_PAGE) {
            onRecordingsVisible()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            val dark = MiuixTheme.colorScheme.onBackground.luminance() > 0.5f
            val barSurface = if (dark) Color(0xFF181B20) else Color.White
            val outline = if (dark) Color(0xFF323842) else Color(0xFFD8E0EA)
            val muted = if (dark) Color(0xFF9CA3AF) else Color(0xFF64748B)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(barSurface)
                    .drawBehind {
                        val dividerWidth = 0.8.dp.toPx()
                        drawLine(
                            color = outline,
                            start = Offset(0f, dividerWidth / 2f),
                            end = Offset(size.width, dividerWidth / 2f),
                            strokeWidth = dividerWidth,
                        )
                    }
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                navigationItems.forEach { (label, symbol, page) ->
                    val selected = recorderPagerState.selectedPage == page
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(13.dp))
                            .clickable { recorderPagerState.animateToPage(page) }
                            .padding(vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (selected) Color(0xFF10B981).copy(alpha = 0.16f) else Color.Transparent)
                                .padding(horizontal = 17.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            BasicText(
                                text = symbol,
                                style = TextStyle(
                                    color = if (selected) Color(0xFF10B981) else muted,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.SemiBold,
                                ),
                            )
                        }
                        Spacer(Modifier.height(2.dp))
                        BasicText(
                            text = label,
                            style = TextStyle(
                                color = if (selected) Color(0xFF10B981) else muted,
                                fontSize = 10.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            ),
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        HorizontalPager(
            state = recorderPagerState.pagerState,
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding()),
            beyondViewportPageCount = 0,
            userScrollEnabled = false,
            verticalAlignment = Alignment.Top,
            key = { page -> page },
        ) { page ->
            when (page) {
                RECORD_PAGE -> recordContent()
                RECORDINGS_PAGE -> recordingsContent()
                else -> settingsContent()
            }
        }
    }
}

@Stable
private class RecorderPagerState(
    val pagerState: PagerState,
    private val coroutineScope: CoroutineScope,
) {
    var selectedPage by mutableIntStateOf(pagerState.currentPage)
        private set

    private var isNavigating by mutableStateOf(false)
    private var navigationJob: Job? = null

    fun animateToPage(targetPage: Int) {
        if (targetPage !in 0 until PAGE_COUNT || targetPage == selectedPage) return

        navigationJob?.cancel()
        selectedPage = targetPage
        isNavigating = true

        navigationJob = coroutineScope.launch {
            val currentJob = coroutineContext.job
            try {
                pagerState.scroll(MutatePriority.UserInput) {
                    val pageDistance = abs(targetPage - pagerState.currentPage).coerceAtLeast(2)
                    val durationMillis = 100 * pageDistance + 100
                    val pageSize = pagerState.layoutInfo.let { it.pageSize + it.pageSpacing }
                    val remainingPages = targetPage -
                        pagerState.currentPage -
                        pagerState.currentPageOffsetFraction
                    val scrollDistance = remainingPages * pageSize
                    var previousValue = 0f

                    animate(
                        initialValue = 0f,
                        targetValue = scrollDistance,
                        animationSpec = tween(
                            durationMillis = durationMillis,
                            easing = EaseInOut,
                        ),
                    ) { currentValue, _ ->
                        previousValue += scrollBy(currentValue - previousValue)
                    }
                }

                if (pagerState.currentPage != targetPage) {
                    pagerState.scrollToPage(targetPage)
                }
            } finally {
                if (navigationJob == currentJob) {
                    isNavigating = false
                    if (pagerState.currentPage != targetPage) {
                        selectedPage = pagerState.currentPage
                    }
                }
            }
        }
    }

    fun syncPage() {
        if (!isNavigating && selectedPage != pagerState.currentPage) {
            selectedPage = pagerState.currentPage
        }
    }
}

@Composable
private fun rememberRecorderPagerState(
    pagerState: PagerState,
    coroutineScope: CoroutineScope = rememberCoroutineScope(),
): RecorderPagerState = remember(pagerState, coroutineScope) {
    RecorderPagerState(pagerState, coroutineScope)
}
