// SPDX-License-Identifier: GPL-3.0-only

package com.openrecorder.app

import android.os.SystemClock
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlin.random.Random
import top.yukonga.miuix.kmp.theme.MiuixTheme

private val RecorderGreen = Color(0xFF10B981)
private val RecorderGreenDark = Color(0xFF059669)
private val RecorderRed = Color(0xFFEF4444)
private val RecorderAmber = Color(0xFFF59E0B)

@Composable
internal fun RecorderScreen(
    recordingState: Int,
    countdownSeconds: Int?,
    actionEnabled: Boolean,
    selectedAudioSource: AudioSource,
    selectedSampleRate: Int,
    selectedCountdownSeconds: Int,
    selectedVideoResolution: Int,
    selectedVideoFrameRate: Int,
    selectedVideoBitrate: Int,
    selectedVideoCodec: Int,
    onAudioSourceSelected: (AudioSource) -> Unit,
    onCountdownSelected: (Int) -> Unit,
    onActionClick: () -> Unit,
    onPauseResumeClick: () -> Unit,
) {
    val dark = MiuixTheme.colorScheme.onBackground.luminance() > 0.5f
    val palette = remember(dark) { RecorderPalette(dark) }
    val elapsedMillis = rememberElapsedMillis(recordingState)
    val profileLabel = buildProfileLabel(
        selectedVideoResolution,
        selectedVideoFrameRate,
        selectedVideoBitrate,
    )
    val outputFormat = if (selectedVideoCodec == RecordingOptions.VIDEO_CODEC_H265) {
        "MP4 (H.265 + AAC)"
    } else {
        "MP4 (H.264 + AAC)"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .statusBarsPadding(),
    ) {
        RecorderHeader(
            recordingState = recordingState,
            countdownSeconds = countdownSeconds,
            palette = palette,
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                QuickTileCard(palette)
            }
            item {
                MonitorCard(
                    recordingState = recordingState,
                    countdownSeconds = countdownSeconds,
                    elapsedMillis = elapsedMillis,
                    profileLabel = profileLabel,
                    outputFormat = outputFormat,
                    selectedAudioSource = selectedAudioSource,
                    selectedSampleRate = selectedSampleRate,
                    selectedVideoBitrate = selectedVideoBitrate,
                    palette = palette,
                )
            }
            item {
                RecordingOptionsCard(
                    selectedAudioSource = selectedAudioSource,
                    selectedCountdownSeconds = selectedCountdownSeconds,
                    enabled = recordingState == RecordingState.IDLE && countdownSeconds == null,
                    onAudioSourceSelected = onAudioSourceSelected,
                    onCountdownSelected = onCountdownSelected,
                    palette = palette,
                )
            }
            item {
                RecordingActions(
                    recordingState = recordingState,
                    countdownSeconds = countdownSeconds,
                    enabled = actionEnabled,
                    onActionClick = onActionClick,
                    onPauseResumeClick = onPauseResumeClick,
                    palette = palette,
                )
            }
            item {
                BasicText(
                    text = stringResource(R.string.home_saved_path),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp),
                    style = TextStyle(
                        color = palette.muted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                    ),
                )
            }
        }
    }
}

@Composable
private fun RecorderHeader(
    recordingState: Int,
    countdownSeconds: Int?,
    palette: RecorderPalette,
) {
    val title = when {
        countdownSeconds != null -> stringResource(R.string.home_status_countdown, countdownSeconds)
        recordingState == RecordingState.RECORDING -> stringResource(R.string.home_status_recording)
        recordingState == RecordingState.PAUSED -> stringResource(R.string.home_status_paused)
        recordingState == RecordingState.PREPARING -> stringResource(R.string.home_status_preparing)
        recordingState == RecordingState.SAVING -> stringResource(R.string.home_status_saving)
        else -> stringResource(R.string.home_status_ready)
    }
    val statusColor = when (recordingState) {
        RecordingState.RECORDING -> RecorderRed
        RecordingState.PAUSED -> RecorderAmber
        RecordingState.PREPARING, RecordingState.SAVING -> Color(0xFF3B82F6)
        else -> RecorderGreen
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.background)
            .drawBehind {
                val dividerWidth = 0.8.dp.toPx()
                drawLine(
                    color = palette.outline,
                    start = Offset(0f, size.height - dividerWidth / 2f),
                    end = Offset(size.width, size.height - dividerWidth / 2f),
                    strokeWidth = dividerWidth,
                )
            }
            .padding(horizontal = 19.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(Brush.linearGradient(listOf(RecorderGreen, Color(0xFF0D9488)))),
            contentAlignment = Alignment.Center,
        ) {
            BasicText(
                text = "◉",
                style = TextStyle(color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold),
            )
        }
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
            BasicText(
                text = "OpenRecorder",
                style = TextStyle(color = palette.text, fontSize = 16.sp, fontWeight = FontWeight.Bold),
            )
            BasicText(
                text = stringResource(R.string.home_subtitle),
                style = TextStyle(color = palette.muted, fontSize = 10.sp),
            )
        }
        Row(
            modifier = Modifier
                .clip(CircleShape)
                .background(statusColor.copy(alpha = 0.12f))
                .border(1.dp, statusColor.copy(alpha = 0.22f), CircleShape)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(statusColor))
            Spacer(Modifier.width(6.dp))
            BasicText(
                text = title,
                style = TextStyle(color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold),
            )
        }
    }
}

@Composable
private fun QuickTileCard(palette: RecorderPalette) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .border(1.dp, palette.outline, RoundedCornerShape(18.dp))
            .padding(13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(RecorderGreen.copy(alpha = 0.13f)),
            contentAlignment = Alignment.Center,
        ) {
            BasicText(text = "ϟ", style = TextStyle(color = RecorderGreen, fontSize = 22.sp, fontWeight = FontWeight.Bold))
        }
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
            BasicText(
                text = stringResource(R.string.home_quick_tile_title),
                style = TextStyle(color = palette.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
            )
            BasicText(
                text = stringResource(R.string.home_quick_tile_summary),
                style = TextStyle(color = palette.muted, fontSize = 10.sp),
            )
        }
        BasicText(
            text = stringResource(R.string.home_available),
            modifier = Modifier
                .clip(RoundedCornerShape(9.dp))
                .background(palette.container)
                .padding(horizontal = 9.dp, vertical = 6.dp),
            style = TextStyle(color = palette.secondaryText, fontSize = 10.sp, fontWeight = FontWeight.Medium),
        )
    }
}

@Composable
private fun MonitorCard(
    recordingState: Int,
    countdownSeconds: Int?,
    elapsedMillis: Long,
    profileLabel: String,
    outputFormat: String,
    selectedAudioSource: AudioSource,
    selectedSampleRate: Int,
    selectedVideoBitrate: Int,
    palette: RecorderPalette,
) {
    val bars = remember { mutableStateListOf<Float>().apply { repeat(24) { add(0.20f) } } }
    val active = recordingState == RecordingState.RECORDING && selectedAudioSource != AudioSource.NONE
    LaunchedEffect(active, recordingState) {
        if (!active) {
            for (index in bars.indices) bars[index] = 0.18f
            return@LaunchedEffect
        }
        while (isActive) {
            for (index in bars.indices) {
                bars[index] = Random.nextFloat().coerceIn(0.12f, 1f)
            }
            delay(130)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(palette.surface)
            .border(1.dp, palette.outline, RoundedCornerShape(24.dp))
            .padding(15.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                text = stringResource(R.string.home_monitor_title),
                modifier = Modifier.weight(1f),
                style = TextStyle(color = palette.muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold),
            )
            BasicText(
                text = profileLabel,
                modifier = Modifier
                    .clip(RoundedCornerShape(7.dp))
                    .background(RecorderGreen.copy(alpha = 0.11f))
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                style = TextStyle(color = RecorderGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            BasicText(
                text = formatDuration(elapsedMillis),
                modifier = Modifier.weight(1f),
                style = TextStyle(color = palette.text, fontSize = 34.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
            )
            Column(horizontalAlignment = Alignment.End) {
                BasicText(text = stringResource(R.string.home_estimated_size), style = TextStyle(color = palette.muted, fontSize = 10.sp))
                BasicText(
                    text = estimateSize(elapsedMillis, selectedVideoBitrate),
                    style = TextStyle(color = palette.secondaryText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace),
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(49.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(palette.container)
                .padding(horizontal = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            bars.forEachIndexed { index, value ->
                val height by animateDpAsState(
                    targetValue = (5f + value * 33f).dp,
                    label = "wave-$index",
                )
                Box(
                    modifier = Modifier
                        .width(4.dp)
                        .height(height)
                        .clip(CircleShape)
                        .background(if (active) RecorderGreen else RecorderGreen.copy(alpha = 0.35f)),
                )
            }
        }
        Spacer(Modifier.height(9.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                text = "${stringResource(R.string.home_audio_source)}: ${audioSourceLabel(selectedAudioSource, selectedSampleRate)}",
                modifier = Modifier.weight(1f),
                style = TextStyle(color = palette.muted, fontSize = 9.sp),
            )
            BasicText(text = outputFormat, style = TextStyle(color = palette.muted, fontSize = 9.sp, fontFamily = FontFamily.Monospace))
        }
        if (countdownSeconds != null) {
            Spacer(Modifier.height(7.dp))
            BasicText(
                text = stringResource(R.string.status_countdown_summary),
                style = TextStyle(color = RecorderAmber, fontSize = 10.sp, fontWeight = FontWeight.Medium),
            )
        }
    }
}

@Composable
private fun RecordingOptionsCard(
    selectedAudioSource: AudioSource,
    selectedCountdownSeconds: Int,
    enabled: Boolean,
    onAudioSourceSelected: (AudioSource) -> Unit,
    onCountdownSelected: (Int) -> Unit,
    palette: RecorderPalette,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(21.dp))
            .background(palette.surface)
            .border(1.dp, palette.outline, RoundedCornerShape(21.dp))
            .padding(13.dp),
    ) {
        BasicText(
            text = stringResource(R.string.home_recording_options),
            style = TextStyle(color = palette.text, fontSize = 13.sp, fontWeight = FontWeight.Bold),
        )
        Spacer(Modifier.height(12.dp))
        BasicText(text = stringResource(R.string.home_audio_source), style = TextStyle(color = palette.muted, fontSize = 10.sp, fontWeight = FontWeight.SemiBold))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(AudioSource.INTERNAL, AudioSource.MICROPHONE, AudioSource.INTERNAL_AND_MICROPHONE, AudioSource.NONE).forEach { source ->
                val selected = selectedAudioSource == source
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) RecorderGreen.copy(alpha = 0.12f) else palette.container)
                        .border(
                            width = 1.dp,
                            color = if (selected) RecorderGreen.copy(alpha = 0.55f) else palette.outline,
                            shape = RoundedCornerShape(12.dp),
                        )
                        .clickable(enabled = enabled) { onAudioSourceSelected(source) }
                        .padding(vertical = 9.dp, horizontal = 3.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    BasicText(
                        text = when (source) {
                            AudioSource.INTERNAL -> "◖))"
                            AudioSource.MICROPHONE -> "●"
                            AudioSource.INTERNAL_AND_MICROPHONE -> "⇄"
                            AudioSource.NONE -> "×"
                        },
                        style = TextStyle(color = if (selected) RecorderGreen else palette.secondaryText, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                    )
                    Spacer(Modifier.height(3.dp))
                    BasicText(
                        text = when (source) {
                            AudioSource.INTERNAL -> stringResource(R.string.home_source_internal)
                            AudioSource.MICROPHONE -> stringResource(R.string.home_source_microphone)
                            AudioSource.INTERNAL_AND_MICROPHONE -> stringResource(R.string.home_source_both)
                            AudioSource.NONE -> stringResource(R.string.home_source_mute)
                        },
                        style = TextStyle(
                            color = if (selected) RecorderGreen else palette.secondaryText,
                            fontSize = 9.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        ),
                        maxLines = 1,
                    )
                }
            }
        }
        Spacer(Modifier.height(13.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BasicText(
                text = stringResource(R.string.home_countdown_label),
                modifier = Modifier.weight(1f),
                style = TextStyle(color = palette.secondaryText, fontSize = 11.sp, fontWeight = FontWeight.Medium),
            )
            listOf(0, 3, 5, 10).forEach { seconds ->
                val selected = selectedCountdownSeconds == seconds
                BasicText(
                    text = if (seconds == 0) {
                        stringResource(R.string.home_countdown_off)
                    } else {
                        stringResource(R.string.home_countdown_value, seconds)
                    },
                    modifier = Modifier
                        .padding(start = 5.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) RecorderGreen.copy(alpha = 0.14f) else palette.container)
                        .border(1.dp, if (selected) RecorderGreen.copy(alpha = 0.45f) else palette.outline, RoundedCornerShape(8.dp))
                        .clickable(enabled = enabled) { onCountdownSelected(seconds) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    style = TextStyle(color = if (selected) RecorderGreen else palette.secondaryText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold),
                )
            }
        }
        if (!enabled) {
            Spacer(Modifier.height(7.dp))
            BasicText(text = stringResource(R.string.home_countdown_disabled), style = TextStyle(color = palette.muted, fontSize = 9.sp))
        }
    }
}

@Composable
private fun RecordingActions(
    recordingState: Int,
    countdownSeconds: Int?,
    enabled: Boolean,
    onActionClick: () -> Unit,
    onPauseResumeClick: () -> Unit,
    palette: RecorderPalette,
) {
    val recording = recordingState == RecordingState.RECORDING || recordingState == RecordingState.PAUSED
    val preparing = countdownSeconds != null || recordingState == RecordingState.PREPARING
    if (recording) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ActionCircle(
                label = if (recordingState == RecordingState.PAUSED) {
                    stringResource(R.string.home_resume)
                } else {
                    stringResource(R.string.home_pause)
                },
                symbol = if (recordingState == RecordingState.PAUSED) "▶" else "Ⅱ",
                color = RecorderAmber,
                size = 65.dp,
                onClick = onPauseResumeClick,
            )
            Spacer(Modifier.width(25.dp))
            ActionCircle(
                label = stringResource(R.string.home_stop),
                symbol = "■",
                color = RecorderRed,
                size = 78.dp,
                onClick = onActionClick,
            )
        }
    } else {
        Column(
            modifier = Modifier.fillMaxWidth().padding(top = 1.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                modifier = Modifier.size(92.dp),
                contentAlignment = Alignment.Center,
            ) {
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .clip(CircleShape)
                        .background(RecorderGreen.copy(alpha = 0.12f)),
                )
                Box(
                    modifier = Modifier
                        .size(78.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(RecorderGreenDark, Color(0xFF2DD4BF))))
                        .clickable(enabled = enabled) { onActionClick() },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        BasicText(text = if (preparing) "×" else "●", style = TextStyle(color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold))
                        BasicText(
                            text = when {
                                preparing -> stringResource(R.string.home_cancel)
                                !enabled -> stringResource(R.string.home_saving)
                                else -> stringResource(R.string.home_start)
                            },
                            style = TextStyle(color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold),
                        )
                    }
                }
            }
            if (preparing) {
                Spacer(Modifier.height(7.dp))
                BasicText(
                    text = stringResource(
                        R.string.home_countdown_description,
                        countdownSeconds?.let { stringResource(R.string.home_countdown_value, it) }
                            ?: stringResource(R.string.home_status_preparing),
                    ),
                    modifier = Modifier.clickable(onClick = onActionClick).padding(5.dp),
                    style = TextStyle(color = palette.muted, fontSize = 10.sp),
                )
            }
        }
    }
}

@Composable
private fun ActionCircle(
    label: String,
    symbol: String,
    color: Color,
    size: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(color)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            BasicText(text = symbol, style = TextStyle(color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold))
        }
        Spacer(Modifier.height(5.dp))
        BasicText(text = label, style = TextStyle(color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold))
    }
}

@Composable
private fun rememberElapsedMillis(recordingState: Int): Long {
    var elapsed by remember { mutableLongStateOf(0L) }
    var accumulated by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }

    LaunchedEffect(recordingState) {
        when (recordingState) {
            RecordingState.RECORDING -> {
                if (startedAt == 0L) startedAt = SystemClock.elapsedRealtime()
                while (isActive) {
                    elapsed = accumulated + (SystemClock.elapsedRealtime() - startedAt)
                    delay(250)
                }
            }
            RecordingState.PAUSED -> {
                if (startedAt != 0L) {
                    accumulated += (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0L)
                    startedAt = 0L
                }
                elapsed = accumulated
            }
            else -> {
                startedAt = 0L
                accumulated = 0L
                elapsed = 0L
            }
        }
    }
    return elapsed
}

private fun formatDuration(elapsedMillis: Long): String {
    val totalSeconds = (elapsedMillis / 1_000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return "%02d:%02d:%02d".format(hours, minutes, seconds)
}

private fun estimateSize(elapsedMillis: Long, bitrate: Int): String {
    if (elapsedMillis <= 0L) return "0.0 MB"
    val bitsPerSecond = when (bitrate) {
        RecordingOptions.VIDEO_BITRATE_4_MBPS -> 4_000_000L
        RecordingOptions.VIDEO_BITRATE_8_MBPS -> 8_000_000L
        RecordingOptions.VIDEO_BITRATE_16_MBPS -> 16_000_000L
        RecordingOptions.VIDEO_BITRATE_24_MBPS -> 24_000_000L
        else -> 8_000_000L
    }
    val megabytes = elapsedMillis.toDouble() / 1_000.0 * bitsPerSecond / 8.0 / 1_000_000.0
    return "%.1f MB".format(megabytes)
}

@Composable
private fun audioSourceLabel(source: AudioSource, sampleRate: Int): String {
    val rate = if (sampleRate == RecordingOptions.SAMPLE_RATE_48_KHZ) "48" else "44.1"
    return when (source) {
        AudioSource.NONE -> stringResource(R.string.home_audio_muted)
        AudioSource.INTERNAL -> stringResource(R.string.home_audio_internal_format, rate)
        AudioSource.MICROPHONE -> stringResource(R.string.home_audio_microphone_format, rate)
        AudioSource.INTERNAL_AND_MICROPHONE -> stringResource(R.string.home_audio_both_format, rate)
    }
}

@Composable
private fun buildProfileLabel(resolution: Int, frameRate: Int, bitrate: Int): String {
    val resolutionLabel = when (resolution) {
        RecordingOptions.VIDEO_RESOLUTION_2160P -> "2160p"
        RecordingOptions.VIDEO_RESOLUTION_1440P -> "1440p"
        RecordingOptions.VIDEO_RESOLUTION_1080P -> "1080p"
        RecordingOptions.VIDEO_RESOLUTION_720P -> "720p"
        RecordingOptions.VIDEO_RESOLUTION_480P -> "480p"
        else -> stringResource(R.string.video_resolution_native)
    }
    val fpsLabel = when (frameRate) {
        RecordingOptions.VIDEO_FRAME_RATE_120_FPS -> "120FPS"
        RecordingOptions.VIDEO_FRAME_RATE_90_FPS -> "90FPS"
        RecordingOptions.VIDEO_FRAME_RATE_60_FPS -> "60FPS"
        RecordingOptions.VIDEO_FRAME_RATE_30_FPS -> "30FPS"
        else -> stringResource(R.string.video_frame_rate_auto)
    }
    val bitrateLabel = when (bitrate) {
        RecordingOptions.VIDEO_BITRATE_4_MBPS -> "4M"
        RecordingOptions.VIDEO_BITRATE_8_MBPS -> "8M"
        RecordingOptions.VIDEO_BITRATE_16_MBPS -> "16M"
        RecordingOptions.VIDEO_BITRATE_24_MBPS -> "24M"
        else -> stringResource(R.string.video_bitrate_auto)
    }
    return "$resolutionLabel · $fpsLabel · $bitrateLabel"
}

private data class RecorderPalette(val dark: Boolean) {
    val background = if (dark) Color(0xFF0F1115) else Color(0xFFF6F8FB)
    val surface = if (dark) Color(0xFF181B20) else Color(0xFFFFFFFF)
    val container = if (dark) Color(0xFF21252C) else Color(0xFFEEF2F7)
    val outline = if (dark) Color(0xFF323842) else Color(0xFFD8E0EA)
    val text = if (dark) Color(0xFFF8FAFC) else Color(0xFF111827)
    val secondaryText = if (dark) Color(0xFFD1D5DB) else Color(0xFF475569)
    val muted = if (dark) Color(0xFF9CA3AF) else Color(0xFF64748B)
}
